﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MISA.CukCuk.Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MISA.CukCuk.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DemoController : ControllerBase
    {
        [HttpGet]
        public string Get()
        {
            var customer = new Customer();
            var customerName = customer.GetName();
            return customerName;
        }

        [HttpGet("filter")]
        public int? GetName([FromQuery]string name, [FromQuery] int? age)
        {
            return age;
        }

        [HttpPost]
        public string Post([FromBody]string name)
        {
            var customer = new Customer();
            var customerName = customer.GetName();
            return customer.FullName;
        }
    }
}
