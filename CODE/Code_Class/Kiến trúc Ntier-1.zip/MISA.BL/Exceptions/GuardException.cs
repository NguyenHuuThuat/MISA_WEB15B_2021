﻿using MISA.Common.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.BL.Exceptions
{
    public class GuardException:Exception
    {
        public GuardException (string msg, Customer customer): base(msg)
        {
            this.Data.Add(1, customer);
        }
    }
}
