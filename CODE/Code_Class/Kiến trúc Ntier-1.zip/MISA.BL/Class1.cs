﻿using System;

namespace MISA.BL
{
    public class Class1
    {
    }
}
