﻿using MISA.Common.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Dapper;
using MySqlConnector;
using System.Linq;

namespace MISA.DL
{
    public class CustomerDL
    {
        public IEnumerable<Customer> GetAll()
        {
            // 1. Khai báo thông tin kết nối tới Database:
            var connectionString = "" +
                "Host = 47.241.69.179;" +
                "Port = 3306;" +
                "Database= MF0_NVManh_CukCuk02;" +
                "User Id = dev;" +
                "Password= 12345678";

            // 2. Khởi tạo kết nối:
            IDbConnection dbConnection = new MySqlConnection(connectionString);

            // 3. Tương tác với Database (lấy dữ liệu, sửa dữ liệu, xóa dữ liệu)
            var sqlCommand = "Proc_DemoGetCustomer";
            var customers = dbConnection.Query<Customer>(sqlCommand, commandType: CommandType.StoredProcedure);
            return customers;
        }

        public Customer GetCustomerById(Guid customerId)
        {
            // 1. Khai báo thông tin kết nối:
            var connectionString = "" +
               "Host = 47.241.69.179;" +
               "Port = 3306;" +
               "Database= MF0_NVManh_CukCuk02;" +
               "User Id = dev;" +
               "Password= 12345678";

            // 2. Khởi tạo kết nối:
            IDbConnection dbConnection = new MySqlConnection(connectionString);
            // 3. Thực thi lệnh lấy dữ liệu trong Database:
            var sqlCommand = $"SELECT * FROM Customer WHERE CustomerId = '{customerId.ToString()}'";
            var customer = dbConnection.QueryFirstOrDefault<Customer>(sqlCommand);
            return customer;
        }

        public int InsertCustomer(Customer customer)
        {
            // 1. Khai báo thông tin kết nối:
            var connectionString = "" +
               "Host = 47.241.69.179;" +
               "Port = 3306;" +
               "Database= MF0_NVManh_CukCuk02;" +
               "User Id = dev;" +
               "Password= 12345678";

            // 2. Khởi tạo kết nối:
            IDbConnection dbConnection = new MySqlConnection(connectionString);
            // 3. Thực thi lệnh lấy dữ liệu trong Database:
            var sqlCommand = $"Proc_InsertCustomer";
            var rowAffects = dbConnection.Execute(sqlCommand, param: customer, commandType: CommandType.StoredProcedure);
            return rowAffects;
        }

        public int UpdateCustomer(Customer customer)
        {
            return 0;
        }

        public int DeleteCustomer(Customer customer)
        {
            return 0;
        }

        public bool CheckCustomerCodeExist(string customerCode)
        {
            // 1. Khai báo thông tin kết nối:
            var connectionString = "" +
               "Host = 47.241.69.179;" +
               "Port = 3306;" +
               "Database= MF0_NVManh_CukCuk02;" +
               "User Id = dev;" +
               "Password= 12345678";

            // 2. Khởi tạo kết nối:
            IDbConnection dbConnection = new MySqlConnection(connectionString);
            // 3. Thực thi lệnh lấy dữ liệu trong Database:
            var sqlCommand = $"Proc_CheckCustomerCodeExists";
            DynamicParameters dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@m_CustomerCode", customerCode);
            var res = dbConnection.ExecuteScalar<bool>(sqlCommand, dynamicParameters, commandType: CommandType.StoredProcedure);
            return res;
        }
    }
}
