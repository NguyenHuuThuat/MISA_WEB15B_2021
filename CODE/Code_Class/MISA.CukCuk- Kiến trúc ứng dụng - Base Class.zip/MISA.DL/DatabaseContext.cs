﻿using System;

namespace MISA.DL
{
    public class DatabaseContext
    {

    }
}
