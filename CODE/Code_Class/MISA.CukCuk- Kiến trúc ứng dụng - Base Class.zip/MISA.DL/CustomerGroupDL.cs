﻿using Dapper;
using MISA.Common.Entities;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace MISA.DL
{
    public class CustomerGroupDL:BaseDL
    {
       
    }
}
